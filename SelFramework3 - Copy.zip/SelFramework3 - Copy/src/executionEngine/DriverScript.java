package executionEngine;

import java.io.FileInputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;

import utility.ExcelUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Config.ActionKeywords;
import Config.Constants;

public class DriverScript {

	public static Method method[];
	public static String sAction = null;
	public static String sObject = null;
	public static String sData = null;
	public static Properties OR;
	public static Properties CONFIG;
	
	public static int iTestStep;
	public static int iTestLastStep;
	public static String sTestCaseID;
	public static String sRunMode;


	public DriverScript() {
	}

	public static void main(String[] args) throws Exception {

		String datafile = Constants.Path_TestData;
		ExcelUtils.setExcelFile(datafile);

		FileInputStream fis = new FileInputStream(Constants.Path_OR);
		OR = new Properties(System.getProperties());
		OR.load(fis);

		FileInputStream fis2 = new FileInputStream(Constants.Path_CONFIG);
		CONFIG = new Properties(System.getProperties());
		CONFIG.load(fis2);

		int iTotalTestCases = ExcelUtils.getRowCount(Constants.Sheet_TestCases);
		System.out.println("iTotalTestCases " + iTotalTestCases);
		for(int j = 1; j <iTotalTestCases;j++)
		{
			
			sTestCaseID = ExcelUtils.getCellData(j, Constants.Col_TestCaseID, Constants.Sheet_TestCases);
			sRunMode = ExcelUtils.getCellData(j, Constants.Col_Runmode, Constants.Sheet_TestCases);
			System.out.println("Executing Test Case" + sTestCaseID);
			
			if(sRunMode.equalsIgnoreCase("yes"))
			{
				iTestStep = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
				
				
				
				int rows = ExcelUtils.getRowCount(Constants.Sheet_TestSteps);
				System.out.println("Total Rows = " + rows);
				
				for (int i  = iTestStep;iTestStep <= rows; i++) {
					System.out.println("Row = " + i);
					if(sTestCaseID.equals(ExcelUtils.getCellData(i, Constants.Col_TestCaseID, Constants.Sheet_TestSteps)))
					{
						System.out.println("Executing Test Step " + ExcelUtils.getCellData(i, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps));
						sAction = ExcelUtils.getCellData(i, Constants.Col_ActionKeyword, Constants.Sheet_TestSteps);
						sObject = ExcelUtils.getCellData(i, Constants.Col_ObjectKeyword, Constants.Sheet_TestSteps);
						sData = ExcelUtils.getCellData(i, Constants.Col_DataKeyword, Constants.Sheet_TestSteps);
						execute_actions();
					}
					else
					{
						break;
					}
										
					
				}
			}
		}
		
		
	}

	public static void execute_actions() throws IllegalAccessException,
			IllegalArgumentException, InvocationTargetException,
			NoSuchMethodException, SecurityException {

		if (sAction.equals("open")) {
			ActionKeywords.open(sObject, sData);
		} else if (sAction.equals("navigate")) {
			ActionKeywords.navigate(sObject, sData);
		} else if (sAction.equals("click")) {
			ActionKeywords.click(sObject, sData);
		} else if (sAction.equals("type")) {
			ActionKeywords.type(sObject, sData);
		} else if (sAction.equals("waitFor")) {
			ActionKeywords.waitFor(sObject, sData);
		} else if (sAction.equals("close")) {
			ActionKeywords.close(sObject, sData);
		} else if (sAction.equals("quit")) {
			ActionKeywords.quit(sObject, sData);
		}
	}

}
