package utility;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Config.Constants;

public class ExcelUtils {

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	static FormulaEvaluator objFormulaEvaluator;
	static DataFormatter objDefaultFormat;

	public static void setExcelFile(String Path) throws Exception {
		FileInputStream ExcelFile = new FileInputStream(Path);
		ExcelWBook = new XSSFWorkbook(ExcelFile);

		objFormulaEvaluator = new XSSFFormulaEvaluator(ExcelWBook);
		objDefaultFormat = new DataFormatter();

	}

	public static String getCellData(int RowNum, int ColNum, String SheetName)
			throws Exception {

		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		
		 try{
          	  Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
                String CellData = Cell.getStringCellValue();
                return CellData;
                }catch (Exception e){
                  return"";
                }
		 
		 
		
	}

	public static int getRowCount(String SheetName) {
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		return ExcelWSheet.getLastRowNum() + 1;

	}

	public static int getRowContains(String sTestCaseName, int colNum,
			String SheetName) throws Exception {
		int i;
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		int rowCount = ExcelUtils.getRowCount(SheetName);
		for (i = 0; i < rowCount; i++) {
			if (ExcelUtils.getCellData(i, colNum, SheetName).equalsIgnoreCase(
					sTestCaseName)) {
				System.out.println("i = " + i + " rowCount = " + rowCount
						+ "sTestCaseName = " + sTestCaseName);
				break;
			}
		}
		return i;
	}

}
