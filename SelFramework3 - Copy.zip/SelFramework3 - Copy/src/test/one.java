package test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class one {

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\lib\\chromedriver.exe");
		
		WebDriver driver = null;

		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		
		//Browser Commands
		driver.get("http://toolsqa.wpengine.com/automation-practice-form/");
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		//System.out.println(driver.getPageSource());
		//driver.close();
		//driver.quit();
		
				String sClass = driver.findElements(By.tagName("button")).toString();
				System.out.println(sClass);
				List<WebElement> list = driver.findElements(By.tagName("button"));
				System.out.println(list.get(0).getText());
				for(WebElement e: list)
				{
					System.out.println(e.getText());
				}
		


Select oSelect = new Select(driver.findElement(By.id("continents")));

oSelect.selectByVisibleText("Europe");

Select bSelect = new Select(driver.findElement(By.id("selenium_commands")));

bSelect.selectByIndex(3);

List<WebElement> list2 = bSelect.getOptions();
System.out.println(list2.size());
for(WebElement s : list2)
{
	System.out.println(s.getText());
}

driver.navigate().to("http://toolsqa.wpengine.com/automation-practice-table/");

for(int i = 1; i <=4; i++)
{
	for(int j=1; j <=6; j++)
	{
		System.out.print(driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[" + i + "]/td[" + j + "]")).getText() + "||");
	}
	System.out.println("");
	
	
}

				
/*		//Navigate Commands
		driver.navigate().to("http://toolsqa.wpengine.com/automation-practice-table/");
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
*/		
		
		
		
		driver.close();
		driver.quit();
	}

}
