package test;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;


public class two {

public static void main(String[] args) throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\lib\\chromedriver.exe");
	
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
	//driver.manage().timeouts().setScriptTimeout(-1,TimeUnit.SECONDS);
	
	/*driver.get("http://toolsqa.wpengine.com/automation-practice-switch-windows/");	 
    driver.findElement(By.id("timingAlert")).click();
    System.out.println("Timer JavaScript Alert is triggered but it is not yet opened");
    WebDriverWait wait = new WebDriverWait(driver, 10);
    Alert alert = wait.until(ExpectedConditions.alertIsPresent());
    System.out.println("Either Pop Up is displayed or it is Timed Out");
    alert.accept();
    System.out.println("Alert Accepted")*/;

    driver.get("https://webqa.ocwencustomers.com/T001/home.jsp");
    
    //WebDriverWait wait = new WebDriverWait(driver, 30);
    
    WebElement e = driver.findElement(By.xpath("//div[contains(@style, '/banners/images/slide_01.jpg')]"));
    
    
    Wait wait = new FluentWait(driver)
    
    .withTimeout(30, TimeUnit.SECONDS)
 
    .pollingEvery(1, TimeUnit.SECONDS)
 
    .ignoring(NoSuchElementException.class);
    
    WebElement element = (WebElement) wait.until(ExpectedConditions.elementToBeClickable(e));
    
    System.out.println("Element Visible to Click");
    
    element.click();
    
    Thread.sleep(10000);
    
    driver.close();
    driver.quit();
    
	/*Map<String, String> mobileEmulation = new HashMap<String, String>();
	mobileEmulation.put("deviceName", "Google Nexus 5");

	Map<String, Object> chromeOptions = new HashMap<String, Object>();
	chromeOptions.put("mobileEmulation", mobileEmulation);
	DesiredCapabilities capabilities = DesiredCapabilities.chrome();
	capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
	WebDriver driver = new ChromeDriver(capabilities);*/
	
	
	
}
}
