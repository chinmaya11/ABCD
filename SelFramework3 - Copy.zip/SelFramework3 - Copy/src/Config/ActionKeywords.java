package Config;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static executionEngine.DriverScript.OR;
import static executionEngine.DriverScript.CONFIG;

public class ActionKeywords {

	public static WebDriver driver;
	
	
	public static void open(String object, String data){
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	
	public static void navigate(String object, String data){
		driver.get(CONFIG.getProperty(data));
	}
	
	public static void click(String object, String data)
	{
		driver.findElement(By.xpath(OR.getProperty(object))).click();
	}
	
	public static void type(String object, String data)
	{
		driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(CONFIG.getProperty(data)); 
	}
	
	public static void waitFor(String object, String data)
	{
		int x = Integer.parseInt(data);
		long time = x * 1000;
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			System.out.println("Error in waitFor");
		}
	}
	
	
	public static void close(String Object, String data)
	{
		driver.close();
	}
	
	public static void quit(String object, String data)
	{
		driver.quit();
	}
	
	
	
	
	
	
	

}
