package Config;

public class Constants {

	public static final String URL = "http://www.store.demoqa.com";
	public static final String Path_TestData = System.getProperty("user.dir") + "\\dataEngine\\DataEngine.xlsx";
	public static final String Path_OR = System.getProperty("user.dir") + "\\configEngine\\OR.txt";
	public static final String Path_CONFIG = System.getProperty("user.dir") + "\\configEngine\\config.txt";
	public static final String File_TestData = "DataEngine.xlsx";
	public static final String Sheet_TestSteps = "Test Steps";
	public static final String Sheet_TestCases = "Test Cases";
	
	//List of Data Sheet Column Numbers
	public static final int Col_TestCaseID = 0;	
	public static final int Col_TestScenarioID =1 ;
	public static final int Col_ActionKeyword =3;
	public static final int Col_ObjectKeyword =4;
	public static final int Col_DataKeyword =5;
	
	public static final int Col_Runmode =2;
	
	
}
 
	//List of Data Engine Excel sheets
	
 
	
